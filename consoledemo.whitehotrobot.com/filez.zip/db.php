<?
	$db_user="user";
	$db_pass="chrome57253";
	$db_host="localhost";
	$db="codegolf";
	$baseDomain="codegolf.dweet.net";
	$appletDomain="applet.codegolf.dweet.net";
        $legacyDomain="legacy.codegolf.dweet.net";
	$baseURL="https://$baseDomain";
        $legacyURL="https://$legacyDomain";
	$appletURL="https://$appletDomain";
	$link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
